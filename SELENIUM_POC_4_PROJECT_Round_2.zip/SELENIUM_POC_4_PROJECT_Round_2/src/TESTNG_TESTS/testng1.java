package TESTNG_TESTS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import BASE_CLASSES.AuthenticationPage;
import BASE_CLASSES.HomePages;

public class testng1 {
	WebDriver wb;
	HomePages hp;
	AuthenticationPage ap;
	@FindBy(xpath="//*[@class='login']")
	WebElement signin;
	
	
	@BeforeClass
	public void home_page()
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
		wb = new ChromeDriver();
		wb.get("http://automationpractice.com/index.php");
	}
	
	@Test(priority=1)
  public void verify_homepage_title() 
	{
		hp = new HomePages(wb);
		ap= new AuthenticationPage(wb);
		String act_result,exp_result="My Store";
		SoftAssert sa = new SoftAssert();
		act_result=hp.verify_title();
		sa.assertEquals(act_result, exp_result);
		sa.assertAll();
	}
	
	@Test(priority=2)
	public void verify_signin_text()
	{
		String act_result,exp_result="Sign in";
		SoftAssert sa = new SoftAssert();
		act_result= hp.verify_text();
		sa.assertEquals(act_result, exp_result);
		sa.assertAll();
	}

	@Test(priority=3)
	  public void verify_authentication_title() 
		{
			String act_result,exp_result="Login - My Store";
			SoftAssert sa = new SoftAssert();
			act_result=ap.verify_title();
			sa.assertEquals(act_result, exp_result);
			sa.assertAll();
		}
}
