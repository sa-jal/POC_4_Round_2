package TESTNG_TESTS;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import BASE_CLASSES.MyAccount;
import BASE_CLASSES.Read_Excel;

@Listeners(BASE_CLASSES.ListenerTest.class)
public class testng2 extends testng1  {
	MyAccount ma;
	Read_Excel re;
	String[][] login_data;
	@FindBy(xpath="//*[@class='logout']")
	WebElement signout;

	@BeforeClass
	public void setup()
	{
		re = new Read_Excel();
		ma= new MyAccount(wb);
		login_data = re.read_excel();
		PageFactory.initElements(wb, this);
	}
	
	@Test(dataProvider="login_data_provider", priority=4)
	public void login_And_Verify_Profile(String email, String password, String exp_result)
	{
		String act_result = ma.login_and_verify_profile(email, password);
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(act_result, exp_result);
		sa.assertAll();
		try {
			signout.click();
			}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

	@DataProvider(name="login_data_provider")
	public String[][] get_data()
	{
		return login_data;
	}
}
