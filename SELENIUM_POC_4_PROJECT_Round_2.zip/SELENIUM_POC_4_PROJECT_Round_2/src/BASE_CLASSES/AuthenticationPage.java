package BASE_CLASSES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AuthenticationPage {
	WebDriver wb;
	WebDriverWait wt;
	public AuthenticationPage(WebDriver wb)
	{
		this.wb=wb;
		PageFactory.initElements(wb, this);
		wt=  new WebDriverWait(wb, 10);
	}
	
	public String verify_title()
	{
		String act_result;
		wt.until(ExpectedConditions.titleContains("Login"));
		act_result = wb.getTitle();
		return act_result;
	}
}
