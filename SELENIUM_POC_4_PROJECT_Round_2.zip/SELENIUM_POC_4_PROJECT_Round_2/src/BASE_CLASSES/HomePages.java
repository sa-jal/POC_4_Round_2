package BASE_CLASSES;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePages {
	WebDriver wb;
	WebDriverWait wt;
	public HomePages(WebDriver wb)
	{
		this.wb=wb;
		PageFactory.initElements(wb, this);
		wt=  new WebDriverWait(wb, 10);
	}
	
	@FindBy(xpath="//*[@class='login']")
	WebElement signin;
	
	public String verify_title()
	{
		String act_result;
		wt.until(ExpectedConditions.titleContains("My"));
		act_result = wb.getTitle();
		return act_result;
	}
	public String verify_text()
	{
		String act_result;
		wt.until(ExpectedConditions.textToBePresentInElement(signin, "Sign"));
		act_result = signin.getText();
		signin.click();
		return act_result;
	}
}

