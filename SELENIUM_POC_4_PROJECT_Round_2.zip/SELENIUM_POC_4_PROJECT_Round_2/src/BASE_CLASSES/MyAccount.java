package BASE_CLASSES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyAccount {
	WebDriver wb;
	WebDriverWait wt;
	@FindBy(xpath="//*[@class='account']")
	WebElement profile_name;
	@FindBy(xpath="//*[@class='logout']")
	WebElement sign_out;
	@FindBy(xpath="//*[@class='login']")
	WebElement signin;
	@FindBy(xpath="//*[@id='email']")
	WebElement em;
	@FindBy(xpath="//*[@id='passwd']")
	WebElement pass;
	@FindBy(xpath="//*[@id='SubmitLogin']")
	WebElement signin_btn;
	public MyAccount(WebDriver wb)
	{
		this.wb=wb;
		PageFactory.initElements(wb, this);
		wt = new WebDriverWait(wb,10);
	}
	
	public String login_and_verify_profile(String email, String password)
	{	
		String act_result=null;
		em.sendKeys(email);
		pass.sendKeys(password);
		signin_btn.click();
		try
		{
			WebElement err=wb.findElement(By.xpath("//*[@id='center_column']/div[1]/ol/li"));
			boolean b=err.isDisplayed();
			if(b)
			{
				act_result= err.getText();
			}
			}
		catch (Exception e) {
			act_result=profile_name.getText();
		
		}
		return act_result;
		}
}
