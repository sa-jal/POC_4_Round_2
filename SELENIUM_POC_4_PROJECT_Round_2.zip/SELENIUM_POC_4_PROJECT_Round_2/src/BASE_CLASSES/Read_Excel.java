package BASE_CLASSES;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Read_Excel {
	private XSSFWorkbook wb;

	public String[][] read_excel()
	{
		int first_row,last_row;
		File f = new File("C:\\Users\\sajal.gupta1\\workspace\\SELENIUM_POC_4_PROJECT_Round_2\\testdata.xlsx");
		FileInputStream fin;
		try {
			String[][] str = null ;
			fin = new FileInputStream(f);
			wb = new XSSFWorkbook(fin);
			XSSFSheet s = wb.getSheet("sheet1");
			first_row=s.getFirstRowNum();
			last_row=s.getLastRowNum();
			str = new String[last_row-first_row][3];
			for(int i=1;i<=last_row;i++)
			{
				XSSFRow r = s.getRow(i);
				XSSFCell c = r.getCell(0);
				XSSFCell c1 = r.getCell(1);
				XSSFCell c2 = r.getCell(2);
				str[i-1][0] = c.getStringCellValue();
				str[i-1][1] = c1.getStringCellValue();
				str[i-1][2] = c2.getStringCellValue();
			}
			return str;
		}
		catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
